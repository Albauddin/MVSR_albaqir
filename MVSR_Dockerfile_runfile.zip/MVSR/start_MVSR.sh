#!/bin/bash

# Allow X11 GUI access
xhost +local:root

# Build the image (only needs to be done once or when Dockerfile changes)
docker build -t vision-mvsr .

# Run the container
docker run -it \
  --env="DISPLAY" \
  --env="QT_X11_NO_MITSHM=1" \
  --env="NVIDIA_VISIBLE_DEVICES=all" \
  --env="NVIDIA_DRIVER_CAPABILITIES=all" \
  --volume="/tmp/.X11-unix:/tmp/.X11-unix:rw" \
  --volume="/dev:/dev" \
  --volume="$HOME/Documents/Docker/Volumes/MVSR:/workspace/data" \
  --volume="$HOME/.ssh:/root/.ssh:ro" \
  --net=host \
  --privileged \
  --runtime=nvidia \
  --name mvsr-vision \
  vision-mvsr

# Revoke X11 access after closing the container
xhost -local:root

